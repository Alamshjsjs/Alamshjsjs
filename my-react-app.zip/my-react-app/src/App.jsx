import React, { useState, useEffect, useCallback } from 'react';
import LoadingScreen from './components/Loading.jsx';
import Navbar from './components/Navbar.jsx';
import Sidebar from './components/Sidebar.jsx';
import Footer from './components/Footer.jsx';
import HomePage from './pages/HomePage.jsx'; // Corrected import
import PmiPage from './pages/PmiPage.jsx';
import { MOCK_DATA } from './data/mockData.js'; 

// ===================================================================================
// == MAIN APP COMPONENT ==
// ===================================================================================
export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState('home'); 
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // --- DATABASE STATE ---
  const [inventoryData, setInventoryData] = useState(MOCK_DATA);

  // Loading animation simulation
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500); 
    return () => clearTimeout(timer);
  }, []);

  // --- DATABASE (CRUD) FUNCTIONS ---

  const handleAddMaterial = useCallback((newData) => {
    setInventoryData(prevData => [
      { ...newData, id: Math.max(...prevData.map(i => i.id), 0) + 1 },
      ...prevData
    ]);
  }, []);

  const handleEditMaterial = useCallback((id, updatedData) => {
    setInventoryData(prevData =>
      prevData.map(item => (item.id === id ? { ...item, ...updatedData } : item))
    );
  }, []);

  const handleUpdateQty = useCallback((id, qtyData) => {
    setInventoryData(prevData =>
      prevData.map(item =>
        item.id === id
          ? {
              ...item,
              perbox_qty: qtyData.perbox_qty,
              total_box: qtyData.total_box,
              total_qty: qtyData.perbox_qty * qtyData.total_box,
            }
          : item
      )
    );
  }, []);

  const handleDeleteMaterial = useCallback((id) => {
    setInventoryData(prevData => prevData.filter(item => item.id !== id));
  }, []);

  // --- Page Routing Logic ---
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />; // HomePage ko render karein
      case 'pmi':
        return (
          <PmiPage
            inventoryData={inventoryData}
            onAdd={handleAddMaterial}
            onEdit={handleEditMaterial}
            onDelete={handleDeleteMaterial}
            onUpdateQty={handleUpdateQty}
          />
        );
      default:
        return <HomePage />;
    }
  };

  // --- MAIN RENDER ---

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar Component */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={(page) => setCurrentPage(page)}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col md:ml-64">
        {/* Navbar Component */}
        <Navbar onToggleSidebar={() => setIsSidebarOpen(true)} />

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto">
          {renderPage()}
        </main>

        {/* Footer Component */}
        <Footer />
      </div>
    </div>
  );
}