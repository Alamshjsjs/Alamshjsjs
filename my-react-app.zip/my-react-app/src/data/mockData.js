// Yeh hamara local (mock) database hai.
// Asli app me, yeh data API se aayega.

export const MOCK_DATA = [
  { id: 1, name: 'Corrugated Box (Small)', perbox_qty: 1, total_box: 150, total_qty: 150, location: 'Rack A-1' },
  { id: 2, name: 'Bubble Wrap (Roll)', perbox_qty: 50, total_box: 10, total_qty: 500, location: 'Rack B-2' },
  { id: 3, name: 'Packing Tape', perbox_qty: 24, total_box: 5, total_qty: 120, location: 'Rack A-2' },
  { id: 4, name: 'Styrofoam Peanuts (Bag)', perbox_qty: 1, total_box: 40, total_qty: 40, location: 'Rack C-1' },
  { id: 5, name: 'Shipping Labels (Roll)', perbox_qty: 500, total_box: 2, total_qty: 1000, location: 'Desk-1' },
];

// Naya form kholne par default values
export const DEFAULT_FORM_STATE = {
  name: '',
  perbox_qty: 1,
  total_box: 0,
  total_qty: 0,
  location: '',
};