import React, { useState, useEffect } from 'react';
// Imports mein .jsx extension add karein
import Button from '../components/ui/Button.jsx';
import Input from '../components/ui/Input.jsx';
import Label from '../components/ui/Label.jsx';
import { DialogFooter } from '../components/ui/Dialog.jsx';

/**
 * MaterialForm Component
 * Yeh form 'Add', 'Edit', aur 'Qty Update' modals ke liye reusable hai.
 */
const MaterialForm = ({ initialData, onSubmit, onClose, isQtyUpdate = false }) => {
  const [formData, setFormData] = useState(initialData);

  // total_qty ko auto-calculate karne ke liye
  useEffect(() => {
    const perbox = parseInt(formData.perbox_qty, 10) || 0;
    const total = parseInt(formData.total_box, 10) || 0;
    setFormData(prev => ({ ...prev, total_qty: perbox * total }));
  }, [formData.perbox_qty, formData.total_box]);

  // Agar initialData (prop) badalta hai, to form ko update karein (Edit/QtyUpdate ke liye zaroori)
  useEffect(() => {
    setFormData(initialData);
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-1">
        <Label htmlFor="name">Material Name</Label>
        <Input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          disabled={isQtyUpdate}
          required
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <Label htmlFor="perbox_qty">Per Box Qty</Label>
          <Input
            id="perbox_qty"
            name="perbox_qty"
            type="number"
            value={formData.perbox_qty}
            onChange={handleChange}
            min="0"
            required
          />
        </div>
        <div className="space-y-1">
          <Label htmlFor="total_box">Total Box</Label>
          <Input
            id="total_box"
            name="total_box"
            type="number"
            value={formData.total_box}
            onChange={handleChange}
            min="0"
            required
          />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="total_qty">Total Qty (Auto-Calculated)</Label>
        <Input
          id="total_qty"
          name="total_qty"
          value={formData.total_qty}
          readOnly
          disabled
          className="bg-gray-100"
        />
      </div>
      <div className="space-y-1">
        <Label htmlFor="location">Location</Label>
        <Input
          id="location"
          name="location"
          value={formData.location}
          onChange={handleChange}
          disabled={isQtyUpdate}
          required
        />
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
        <Button type="submit" variant="default">
          {isQtyUpdate ? 'Update Quantity' : 'Save Material'}
        </Button>
      </DialogFooter>
    </form>
  );
};

export default MaterialForm;