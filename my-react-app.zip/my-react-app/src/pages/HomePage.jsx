import React from 'react';
// UI components ko .jsx extension ke saath import karein
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card.jsx'; 

/**
 * HomePage Component
 * Welcome page.
 */
const HomePage = () => (
  <div className="p-4 md:p-6">
    <Card>
      <CardHeader>
        <CardTitle>Welcome to NUA IMS</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-700">
          Aapka NUA Inventory Management System me swagat hai.
          <br />
          Kripya shuru karne ke liye sidebar se ek option chunein.
        </p>
      </CardContent>
    </Card>
  </div>
);

export default HomePage;