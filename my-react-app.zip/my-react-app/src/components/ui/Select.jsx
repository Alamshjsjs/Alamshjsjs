import React from 'react';
import { IconChevronsUpDown } from '../Icons';

/**
 * Select Component
 * Pagination limit ke liye dropdown.
 */
const Select = ({ children, className = '', ...props }) => (
  <div className="relative">
    <select
      className={`h-10 w-full appearance-none rounded-md border border-gray-300 bg-white px-3 py-2 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${className}`}
      {...props}
    >
      {children}
    </select>
    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
      <IconChevronsUpDown />
    </div>
  </div>
);

export default Select;