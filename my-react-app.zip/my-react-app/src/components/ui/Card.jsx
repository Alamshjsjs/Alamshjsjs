import React from 'react';

/**
 * Card Component
 * Content ko wrap karne ke liye card.
 */
export const Card = ({ children, className = '' }) => (
  <div className={`rounded-xl border bg-white shadow-lg transition-shadow hover:shadow-xl ${className}`}>
    {children}
  </div>
);

export const CardHeader = ({ children, className = '' }) => (
  <div className={`flex flex-col space-y-1.5 p-6 border-b ${className}`}>{children}</div>
);

export const CardTitle = ({ children, className = '' }) => (
  <h3 className={`text-2xl font-bold text-gray-800 ${className}`}>{children}</h3>
);

export const CardContent = ({ children, className = '' }) => (
  <div className={`p-6 pt-4 ${className}`}>{children}</div>
);