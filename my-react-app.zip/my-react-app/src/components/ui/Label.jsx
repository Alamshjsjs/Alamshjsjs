import React from 'react';

/**
 * Label Component
 * Form inputs ke liye label.
 */
const Label = ({ className = '', ...props }) => (
  <label
    className={`text-sm font-medium leading-none text-gray-700 ${className}`}
    {...props}
  />
);

export default Label;