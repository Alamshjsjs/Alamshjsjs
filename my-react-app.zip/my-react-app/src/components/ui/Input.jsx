import React from 'react';

/**
 * Input Component
 * Ek standard input field.
 */
const Input = React.forwardRef(({ className = '', ...props }, ref) => (
  <input
    className={`flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${className}`}
    ref={ref}
    {...props}
  />
));

export default Input;