import React from 'react';

/**
 * Footer Component
 * Page ke bottom par dikhta hai.
 */
const Footer = () => (
  <footer className="h-12 w-full border-t bg-white px-4 text-center text-sm text-gray-500 flex items-center justify-center shrink-0">
    &copy; {new Date().getFullYear()} NUA Inventory Management System. All rights reserved.
  </footer>
);

export default Footer;