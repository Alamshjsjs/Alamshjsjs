import React from 'react';

// ===================================
// == Icon Components (SVG) ==
// ===================================

const baseIconClasses = "h-5 w-5";

export const IconHome = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
);

export const IconPackage = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m7.5 4.27 9 5.15"/><path d="m21 12-9 5.15L3 12"/><path d="m3 6 9-5.15 9 5.15"/><path d="M12 22.78V17.5"/><path d="M21 12v5.15"/><path d="M3 12v5.15"/></svg>
);

export const IconBoxes = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v3"/><path d="M10 12h4"/><path d="M12 10v4"/><path d="M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-3H3z"/></svg>
);

export const IconChevronDown = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
);

export const IconMenu = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
);

export const IconUser = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
);

export const IconSearch = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
);

export const IconPlus = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
);

export const IconEdit = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
);

export const IconTrash = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
);

export const IconPackageImport = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 10h16"/><path d="M8 6h8"/><path d="M15 16H9"/><path d="m12 13 3 3-3 3"/></svg>
);

export const IconPackageExport = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 14h16"/><path d="M8 18h8"/><path d="M15 8H9"/><path d="m12 11 3-3-3-3"/></svg>
);

export const IconChevronsUpDown = (props) => (
  <svg {...props} className={`${baseIconClasses} ${props.className}`} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/></svg>
);