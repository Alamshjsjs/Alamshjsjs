import React, { useState } from 'react';
// Yahan extension .jsx add karna zaruri hai (Vite standard)
import { IconHome, IconPackage, IconBoxes, IconChevronDown } from './Icons.jsx';

/**
 * Sidebar Component
 * Yeh left-side navigation menu hai.
 */
const Sidebar = ({ isOpen, onClose, currentPage, onNavigate }) => {
  const [isInventoryOpen, setIsInventoryOpen] = useState(true);

  // Internal component navigation link ke liye
  const NavLink = ({ page, label, icon, isSubLink = false }) => (
    <li>
      <button
        onClick={() => onNavigate(page)}
        className={`flex w-full items-center rounded-lg p-2 text-base transition-all duration-200
          ${isSubLink ? 'pl-11' : 'pl-3'}
          ${currentPage === page
            ? 'bg-indigo-600 text-white'
            : 'text-gray-300 hover:bg-gray-700 hover:text-white'
          }`}
      >
        {icon}
        <span className="ml-3 flex-1 whitespace-nowrap">{label}</span>
      </button>
    </li>
  );

  return (
    <>
      {/* Mobile par sidebar khulne par piche ka backdrop */}
      <div
        className={`fixed inset-0 z-30 bg-black/50 md:hidden ${isOpen ? 'block' : 'hidden'}`}
        onClick={onClose}
      ></div>
      {/* Asal Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-40 h-screen w-64 -translate-x-full bg-gray-900 text-white transition-transform md:translate-x-0 ${isOpen ? 'translate-x-0' : ''}`}
      >
        <div className="flex h-16 items-center justify-center border-b border-gray-700">
          <span className="text-2xl font-bold">NUA IMS</span>
        </div>
        <nav className="flex-1 overflow-y-auto p-4">
          <ul className="space-y-2">
            <NavLink page="home" label="Home" icon={<IconHome />} />
            {/* Inventory Dropdown */}
            <li>
              <button
                onClick={() => setIsInventoryOpen(!isInventoryOpen)}
                className="flex w-full items-center rounded-lg p-2 pl-3 text-base text-gray-300 transition-all duration-200 hover:bg-gray-700 hover:text-white"
              >
                <IconPackage />
                <span className="ml-3 flex-1 whitespace-nowrap text-left">Inventory</span>
                <IconChevronDown />
              </button>
              {isInventoryOpen && (
                <ul className="pt-2 space-y-2">
                  <NavLink page="pmi" label="Packing Material" icon={<IconBoxes />} isSubLink />
                </ul>
              )}
            </li>
          </ul>
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;