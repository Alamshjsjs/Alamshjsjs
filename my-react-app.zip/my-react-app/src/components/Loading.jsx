import React from 'react';

/**
 * LoadingScreen Component
 * App load hone tak dikhta hai.
 */
const LoadingScreen = () => (
  <div className="flex h-screen w-full items-center justify-center bg-gray-50">
    <div className="text-center">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-indigo-500 border-t-transparent mx-auto"></div>
      <h1 className="mt-4 text-2xl font-semibold text-gray-800">Loading NUA IMS...</h1>
      <p className="text-gray-500">Initializing system components.</p>
    </div>
  </div>
);

export default LoadingScreen;