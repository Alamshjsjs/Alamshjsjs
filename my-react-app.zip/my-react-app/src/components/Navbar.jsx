import React from 'react';
import { IconMenu, IconUser } from './Icons.jsx'; // Corrected extension

/**
 * Navbar Component
 * Mobile menu toggle aur user info dikhata hai.
 */
const Navbar = ({ onToggleSidebar }) => (
  <header className="sticky top-0 z-10 flex h-16 shrink-0 items-center justify-between border-b bg-white px-4 shadow-sm md:justify-end md:px-6">
    {/* Mobile Menu Button (md screen size tak hide) */}
    <button
      onClick={onToggleSidebar}
      className="rounded-lg p-2 text-gray-600 transition-colors hover:bg-gray-100 md:hidden"
      aria-label="Toggle Menu"
    >
      <IconMenu className="h-6 w-6" />
    </button>

    {/* Desktop Logo (Mobile par hide) */}
    <div className="flex items-center text-xl font-bold text-gray-800 md:hidden">
      NUA IMS
    </div>

    {/* User Profile / Actions */}
    <div className="flex items-center space-x-4">
      <div className="text-right">
        <p className="text-sm font-medium text-gray-900">Admin User</p>
        <p className="text-xs text-gray-500">nua.ims@example.com</p>
      </div>
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-500 text-white">
        <IconUser className="h-5 w-5" />
      </div>
    </div>
  </header>
);

export default Navbar;