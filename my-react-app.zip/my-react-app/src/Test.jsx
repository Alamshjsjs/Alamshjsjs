import React from 'react';

// Yeh component 100% chalna chahiye
const TestComponent = () => {
  return (
    <div className="flex h-screen w-full items-center justify-center bg-green-500">
      <h1 className="text-4xl font-bold text-white p-6 rounded-lg bg-green-700 shadow-xl">
        🎉 TEST SUCCESSFUL! 🎉
      </h1>
    </div>
  );
};

export default TestComponent;